Name1="XUWEN"
Name2="xuwen"
Name3=Name2.upper()
print("Name1==Name2;",Name1==Name2)
print("Name1==Name3:",Name1==Name3)
x=4
y=6
print("x==y:",x==y)
print("x!=y:",x!=y)
a=[0,6.6,"python"]
list2=[1,2,3,4,5,6,7]
len(list2)
list1=["hello","python",2018,814]
list1.append(2049)
print(list1)
list2=[23,2018,814,2049,2018]
list2.count(2018)
list1.extend(list2)
print("Extended list:",list1)
print("Index for python:",list1.index('python'))
print("Index for 2018:",list1.index(2018))
list=["hello","python",2018,2009, 814, 23, 2018, 814, 2049, 




