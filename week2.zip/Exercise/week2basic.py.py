print("hello")
print(1+2)
a=1+2
print(a)
a=int(7.9)
print(a)
test=[]
print(test,"is",bool(test))
test=[0]
print(test,"is",bool(test))
test=0.0
print(test,"is",bool(test))
test=None
print(test,"is",bool(test))
test=True
print(test,"is",bool(test))
test="Loving you"
print(test,"is",bool(test))
print("Xiao Ming says'I don't feel well today'")
print("xiao\\ Ming\n says\r I\t don't \b feel\f well\v")
print("I don' feel well\ntoday")
a=10//3
b=10%3
c=10**3
print("a=",a,"b=",b,"c=",c)
r=0.05
n=20
P=5000000
A=r*P*(1+r)**n/((1+r)**n-1)
print("A=",A)
print("hello")


