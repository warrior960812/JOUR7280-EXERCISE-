test1="python"
test1.lower()
print（"test!")
